--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.12
-- Dumped by pg_dump version 11.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "RiskApp";
--
-- Name: RiskApp; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "RiskApp" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE "RiskApp" OWNER TO postgres;

\connect "RiskApp"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    account_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    password character varying(256) NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.account OWNER TO postgres;

--
-- Name: account_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_role (
    account_id uuid NOT NULL,
    application_role_id uuid NOT NULL,
    created_date time with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.account_role OWNER TO postgres;

--
-- Name: application_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_role (
    application_role_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(256) NOT NULL
);


ALTER TABLE public.application_role OWNER TO postgres;

--
-- Name: company; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company (
    company_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_name character varying(1024) NOT NULL,
    company_type character varying(1024) NOT NULL,
    email_domain character varying(2048) NOT NULL
);


ALTER TABLE public.company OWNER TO postgres;

--
-- Name: opportunity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opportunity (
    opportunity_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    status character varying(50) NOT NULL,
    insurance_types character varying(50)[] NOT NULL,
    state character varying(25) NOT NULL,
    created_by_profile_id uuid NOT NULL,
    created_date time with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    detail jsonb NOT NULL
);


ALTER TABLE public.opportunity OWNER TO postgres;

--
-- Name: opportunity_match; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opportunity_match (
    opportunity_match_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    opportunity_id uuid NOT NULL,
    created_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status character varying(25) NOT NULL,
    matched_by_profile_id uuid NOT NULL
);


ALTER TABLE public.opportunity_match OWNER TO postgres;

--
-- Name: profile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profile (
    profile_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    account_id uuid,
    company_id uuid,
    first_name character varying(255),
    last_name character varying(255),
    phone character(255),
    email character varying(255) NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.profile OWNER TO postgres;

--
-- Name: registration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registration (
    registration_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    registration_code character varying(255) NOT NULL,
    expires_date timestamp with time zone NOT NULL,
    account_id uuid,
    company_id uuid,
    accept_date timestamp with time zone,
    email character varying(255) NOT NULL,
    roles uuid[]
);


ALTER TABLE public.registration OWNER TO postgres;

--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account (account_id, password, create_date) FROM stdin;
\.
COPY public.account (account_id, password, create_date) FROM '$$PATH$$/2884.dat';

--
-- Data for Name: account_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_role (account_id, application_role_id, created_date) FROM stdin;
\.
COPY public.account_role (account_id, application_role_id, created_date) FROM '$$PATH$$/2886.dat';

--
-- Data for Name: application_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_role (application_role_id, name) FROM stdin;
\.
COPY public.application_role (application_role_id, name) FROM '$$PATH$$/2885.dat';

--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company (company_id, company_name, company_type, email_domain) FROM stdin;
\.
COPY public.company (company_id, company_name, company_type, email_domain) FROM '$$PATH$$/2890.dat';

--
-- Data for Name: opportunity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opportunity (opportunity_id, status, insurance_types, state, created_by_profile_id, created_date, detail) FROM stdin;
\.
COPY public.opportunity (opportunity_id, status, insurance_types, state, created_by_profile_id, created_date, detail) FROM '$$PATH$$/2887.dat';

--
-- Data for Name: opportunity_match; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opportunity_match (opportunity_match_id, opportunity_id, created_date, status, matched_by_profile_id) FROM stdin;
\.
COPY public.opportunity_match (opportunity_match_id, opportunity_id, created_date, status, matched_by_profile_id) FROM '$$PATH$$/2888.dat';

--
-- Data for Name: profile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profile (profile_id, account_id, company_id, first_name, last_name, phone, email, create_date) FROM stdin;
\.
COPY public.profile (profile_id, account_id, company_id, first_name, last_name, phone, email, create_date) FROM '$$PATH$$/2891.dat';

--
-- Data for Name: registration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registration (registration_id, created_date, registration_code, expires_date, account_id, company_id, accept_date, email, roles) FROM stdin;
\.
COPY public.registration (registration_id, created_date, registration_code, expires_date, account_id, company_id, accept_date, email, roles) FROM '$$PATH$$/2889.dat';

--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (account_id);


--
-- Name: application_role application_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_role
    ADD CONSTRAINT application_role_pkey PRIMARY KEY (application_role_id);


--
-- Name: account_role applicationroleaccount_id_ux; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_role
    ADD CONSTRAINT applicationroleaccount_id_ux UNIQUE (application_role_id, account_id);


--
-- Name: company company_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT company_pkey PRIMARY KEY (company_id);


--
-- Name: profile email_ux; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile
    ADD CONSTRAINT email_ux UNIQUE (email);


--
-- Name: opportunity_match opportunity_match_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opportunity_match
    ADD CONSTRAINT opportunity_match_pkey PRIMARY KEY (opportunity_match_id);


--
-- Name: opportunity opportunity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opportunity
    ADD CONSTRAINT opportunity_pkey PRIMARY KEY (opportunity_id);


--
-- Name: profile profile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profile
    ADD CONSTRAINT profile_pkey PRIMARY KEY (profile_id);


--
-- Name: registration registration_id_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration
    ADD CONSTRAINT registration_id_pkey PRIMARY KEY (registration_id);


--
-- Name: profile_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX profile_email_idx ON public.profile USING btree (email);


--
-- Name: registration acountid_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration
    ADD CONSTRAINT acountid_fk FOREIGN KEY (account_id) REFERENCES public.account(account_id);


--
-- Name: account_role ar_account_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_role
    ADD CONSTRAINT ar_account_id_fk FOREIGN KEY (account_id) REFERENCES public.account(account_id);


--
-- Name: account_role ar_aplication_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_role
    ADD CONSTRAINT ar_aplication_role_fk FOREIGN KEY (application_role_id) REFERENCES public.application_role(application_role_id);


--
-- Name: opportunity_match opportunity_opportunity_match_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opportunity_match
    ADD CONSTRAINT opportunity_opportunity_match_fkey FOREIGN KEY (opportunity_id) REFERENCES public.opportunity(opportunity_id);


--
-- Name: DATABASE "RiskApp"; Type: ACL; Schema: -; Owner: postgres
--

GRANT CONNECT ON DATABASE "RiskApp" TO riskappweb;


--
-- Name: TABLE account; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.account TO riskappweb;


--
-- Name: TABLE account_role; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.account_role TO riskappweb;


--
-- Name: TABLE application_role; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.application_role TO riskappweb;


--
-- Name: TABLE company; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.company TO riskappweb;


--
-- Name: TABLE opportunity; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.opportunity TO riskappweb;


--
-- Name: TABLE opportunity_match; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.opportunity_match TO riskappweb;


--
-- Name: TABLE profile; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.profile TO riskappweb;


--
-- Name: TABLE registration; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.registration TO riskappweb;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TABLES  TO riskappweb;


--
-- PostgreSQL database dump complete
--

